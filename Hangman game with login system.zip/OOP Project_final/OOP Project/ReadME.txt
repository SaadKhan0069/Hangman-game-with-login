This project first asks to signup. Then use the credentials of the created account to login and start playing the game. The username and password is stored in the MS Access database file in the login system -> login system -> bin -> debug folder.

In order to run the program, follow these instructions.
GOTO ->Login System->Login System.sln


